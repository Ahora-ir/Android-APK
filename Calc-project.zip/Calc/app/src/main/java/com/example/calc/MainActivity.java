package com.example.calc;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.math.BigDecimal;
import java.math.MathContext;

public class MainActivity extends Activity {

    private TextView display;
    private TextView expr;
    private String current = "0";
    private double acc = 0;
    private String op = null;
    private boolean fresh = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#121212"));
        root.setPadding(dp(12), dp(24), dp(12), dp(12));

        expr = new TextView(this);
        expr.setTextColor(Color.parseColor("#9E9E9E"));
        expr.setTextSize(20);
        expr.setGravity(Gravity.END | Gravity.BOTTOM);
        root.addView(expr, new LinearLayout.LayoutParams(-1, 0, 0.6f));

        display = new TextView(this);
        display.setTextColor(Color.WHITE);
        display.setTextSize(52);
        display.setTypeface(Typeface.DEFAULT_BOLD);
        display.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        display.setSingleLine(true);
        display.setPadding(0, 0, dp(8), dp(8));
        root.addView(display, new LinearLayout.LayoutParams(-1, 0, 1.2f));

        String[][] rows = {
                {"C", "⌫", "%", "÷"},
                {"7", "8", "9", "×"},
                {"4", "5", "6", "−"},
                {"1", "2", "3", "+"},
                {"0", ".", "="}
        };
        for (String[] r : rows) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (String label : r) {
                float w = (label.equals("0")) ? 2f : 1f;
                if (r.length == 3 && !label.equals("0")) w = 1f;
                row.addView(makeButton(label), new LinearLayout.LayoutParams(0, -1, w));
            }
            root.addView(row, new LinearLayout.LayoutParams(-1, 0, 1f));
        }
        setContentView(root);
        refresh();
    }

    private Button makeButton(final String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(26);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        String color = "#2C2C2C";
        if ("÷×−+=".contains(label)) color = "#FF9800";
        else if (label.equals("C") || label.equals("⌫") || label.equals("%")) color = "#4A4A4A";
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(color));
        bg.setCornerRadius(dp(18));
        b.setBackground(bg);
        LinearLayout.LayoutParams unused = null;
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                press(label);
            }
        });
        // margin via wrapper trick: use padding on parent through layout params
        b.setStateListAnimator(null);
        return b;
    }

    private void press(String k) {
        if (current.equals("خطا") && !k.equals("C")) {
            clearAll();
        }
        switch (k) {
            case "C":
                clearAll();
                break;
            case "⌫":
                if (!fresh) {
                    current = current.length() > 1 ? current.substring(0, current.length() - 1) : "0";
                    if (current.equals("-")) current = "0";
                }
                break;
            case ".":
                if (fresh) {
                    current = "0.";
                    fresh = false;
                } else if (!current.contains(".")) {
                    current += ".";
                }
                break;
            case "%":
                current = format(parse(current) / 100.0);
                fresh = false;
                break;
            case "+":
            case "−":
            case "×":
            case "÷":
                if (op != null && !fresh) {
                    if (!calculate()) break;
                } else {
                    acc = parse(current);
                }
                op = k;
                fresh = true;
                break;
            case "=":
                if (op != null) {
                    if (calculate()) {
                        op = null;
                        fresh = true;
                    }
                }
                break;
            default:
                if (fresh) {
                    current = k;
                    fresh = false;
                } else {
                    current = current.equals("0") ? k : current + k;
                }
        }
        refresh();
    }

    private boolean calculate() {
        double b = parse(current);
        double r;
        switch (op) {
            case "+": r = acc + b; break;
            case "−": r = acc - b; break;
            case "×": r = acc * b; break;
            default:
                if (b == 0) {
                    clearAll();
                    current = "خطا";
                    return false;
                }
                r = acc / b;
        }
        acc = r;
        current = format(r);
        return true;
    }

    private void clearAll() {
        current = "0";
        acc = 0;
        op = null;
        fresh = true;
    }

    private double parse(String s) {
        try {
            return Double.parseDouble(s);
        } catch (Exception e) {
            return 0;
        }
    }

    private String format(double v) {
        if (Double.isNaN(v) || Double.isInfinite(v)) return "خطا";
        BigDecimal bd = new BigDecimal(v).round(new MathContext(12)).stripTrailingZeros();
        return bd.toPlainString();
    }

    private void refresh() {
        display.setText(current);
        if (op != null) {
            expr.setText(format(acc) + " " + op);
        } else {
            expr.setText("");
        }
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }
}
